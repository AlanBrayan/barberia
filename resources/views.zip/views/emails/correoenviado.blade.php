<!DOCTYPE html>
<html>
    <head>
        <title>Email Urbancut</title>
    </head>
<body>
    <h1>{{ $details['title'] }}</h1>
    <p>Correo que te contacto : {{ $details['correo'] }}</p>
    <p>{{ $details['body'] }}</p>
    <p>Gracias</p>
    <img src="https://utvt.edomex.gob.mx/sites/utvt.edomex.gob.mx/files/images/1%20copia.jpg">
</body>
</html>