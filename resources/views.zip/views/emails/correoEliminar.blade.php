<!DOCTYPE html>
<html>
    <head>
        <title>Email Urbancut</title>
    </head>
<body>
    <h1>USUARIO ELIMINADO</h1>
    <p>Tu usario ha sido eliminado</p>
    <p></p>
    <p>Gracias</p>
    <img src="https://utvt.edomex.gob.mx/sites/utvt.edomex.gob.mx/files/images/1%20copia.jpg">
</body>
</html>