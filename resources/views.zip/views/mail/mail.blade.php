<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Correo | Email - UTVT</title>
</head>
<body text "#cccccc">
    <center>
        <img src="https://utvtblog.files.wordpress.com/2017/04/cropped-logo-utvt.png" > <br>
        <h1>Ejemplo: {{ $ejemplo }}</h1><br>
        <hr>
        Estimado {{ $nombre }} ({{ $correo }}) <br>
        <br>
        Le agradecemos el realizar el ejemplo del correo..... <br>
        con el mensaje:
        <h3>{{ $mensaje }}</h3><br>
        con el asunto: <b>{{ $asunto }}</b><br>
        <br>

    </center>

</body>
</html>