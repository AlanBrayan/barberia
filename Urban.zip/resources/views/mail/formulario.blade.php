
<H1>Correo | Email</H1>
<hr>
<h3>Enviar correo 01</h3>
<a href="{{ route('enviar1') }}">Emviar-01</a>
<hr>
<br>
<!-- <form action="{{ route('enviar2') }}" method="POST" name="correo">
{{ csrf_field() }}

    Nombre : <input type="text" name="nombre" value="{{ old('nombre')}}"><br>
    Email : <input type="text" name="correo" value="{{ old('correo')}}"> <br>
    Asunto : <input type="text" name="asunto" value="{{ old('asunto')}}"><br>
    Mensaje: <textarea name="mensaje"></textarea><br>
    <input type="submit" value="Enviar-02"><br>
</form> -->
