<!-- Header -->
<header id="header">
	<a href="<?php echo e(route('home')); ?>" class="logo"><strong>Joyeria</strong> Luminosité</a>
	<?php if(empty(session('session_id'))): ?>
	<h1></h1>
	<?php else: ?>
	
	Hola <?php echo e(session('session_name')); ?>


	<?php endif; ?>
	<ul class="icons">

		<?php if(!empty(session('session_id'))): ?>

		<a href="<?php echo e(route ('logout')); ?>" class="button big">Log Out</a>

		<?php if(count(Cart::getContent())): ?>

		<a href="<?php echo e(route('carrito')); ?>" class="button big"> VER CARRITO </a>

		<?php endif; ?>

		<?php else: ?>
		<h1></h1>
		<?php endif; ?>

	</ul>
</header><?php /**PATH C:\xampp\htdocs\proyecto_integrador2\resources\views/layouts/header.blade.php ENDPATH**/ ?>