<!DOCTYPE HTML>
<!--
	Editorial by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>

<head>
	<title>Inicio</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>" />
	<script src=" <?php echo e(asset('js/jquery-3.3.1.js')); ?> "></script>
	<script src=" <?php echo e(asset('js/jquery-ui.js')); ?> "></script>

</head>

<body class="is-preload">

	<!-- Wrapper -->
	<div id="wrapper">

		<!-- Main -->
		<div id="main">
			<div class="inner">

			<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			<h2>Nueva Venta</h2>


				<form action="<?php echo e(route ('guardarCitas')); ?>" method="POST" name="nuevo">

					<?php echo e(csrf_field()); ?>


					<div style="padding: 1%;">
					USUARIO: 
					<select name="id_usuario" id="id_usuario">
						<option value="<?php echo e(session('session_id')); ?>"><?php echo e(session('session_name')); ?></option>
					</select>						
					</div>
					<?php if($errors->first('id_usuario')): ?> <i><?php echo e($errors -> first ('id_usuario')); ?></i><?php endif; ?>

					<div style="padding: 1%;">

						Selecciona el empleado <select name="id_empleado" id="id_empleado" >
							<option value="">--Selecciona un usuario--</option>
							<?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($empleado->id_empleado); ?>"><?php echo e($empleado->nombre); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
						
					</div>
					<?php if($errors->first('id_empleado')): ?> <i><?php echo e($errors -> first ('id_empleado')); ?></i><?php endif; ?>


					<div style="padding: 1%;">
						Escribe la fecha de cita: <input type="date" name="fecha" value="<?php echo e(old('fecha')); ?>">
					</div>
					<?php if($errors->first('fecha')): ?> <i><?php echo e($errors -> first ('fecha')); ?></i><?php endif; ?>

					<div style="padding: 1%;">
						Hora de cita: <input type="time" name="hora" value="<?php echo e(old('hora')); ?>">
					</div>
					<?php if($errors->first('hora')): ?> <i><?php echo e($errors -> first ('hora')); ?></i><?php endif; ?>
					

					<div style="padding: 1%;">
						Selecciona el servicio: 
						<select name="id_servicio" id="id_servicio">
							<option value="">--Selecciona un servicio--</option>
							<?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							
							
							<option value="<?php echo e($servicio->id_servicio); ?>"><?php echo e($servicio->nombre_servicio); ?> -----------------------  Costo: $<?php echo e($servicio->precio); ?></option><br>
				

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>

						
					</div>
					<hr>
					
					

					
					<hr>

					

					<input type="submit" value="Enviar">
				</form>

			</div>
		</div>

		<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	</div>

	<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
<script>
	$(document).ready(function(){
		var id = $('#id_usuario').val();
		console.log("id"+id);
	})
	
</script>




</html><?php /**PATH C:\xampp\htdocs\Urban\resources\views/templates/registrar_cita_usuario.blade.php ENDPATH**/ ?>