<!DOCTYPE HTML>
<html>
<head>
	<title>Reporte de Usuarios </title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>" />

</head>

<style>
	.card {
		box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
		transition: 0.3s;

		border-radius: 5px;
		text-align: center;
	}

	.card:hover {
		box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
	}

	img {
		border-radius: 5px 5px 0 0;
	}

	.container {
		padding: 2px 16px;
    }
    table th{
        background-color: #337ab7 !important;
        color: white;

    }

    table>tbody>tr>td{
        vertical-align: middle !important;
    }

    .btn-group, .btn-group-vertical{
        position: absolute !important;
    }
</style>

<body class="is-preload">

	<!-- Wrapper -->
	<div id="wrapper">

		<!-- Main -->
		<div id="main">
			<div class="inner">

				<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 <!-- <meta charset="uf-8"> -->
	<meta name="viewport" content="with=dev-width, initial-scale=1, shrink-to-fit=no">
	<link rel="shortcut icon" href="#">

		<title>Reporte de Usuarios </title>
		<br>
		<br>
		<!-- Bostrap css -->
		<link rel="stylesheet" href="boostrap/css/bootstrap.min.css">
	
<!-- data tables css basico -->
<link rel="stylesheet" type="text/css" href="datatables/datatables.min.css" />
<!-- datatablesestiloboostrap 4 css  -->
<link rel="stylesheet" type="text/css" href="datatables/DataTables-1.10.18/css/datatables.bootstrap4.min.css">
<!-- font awesome con cdn  -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" 
integrity="sha384-oS3vJWV+0UjzBFQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
<!-- <script src="https://kit.fontawesome.com/e7271ede2b.js" crossorigin="anonymous"></script> -->
  
</head>
	<body >
		<head>
			<h1 class="text-center text-light">Reporte de Usuarios</h1>
		</head>

     <p>Click <a href="<?php echo e(route('usuarios.excel')); ?>">Aqui</a> Para descargar en excel </p>
     <p>Click <a href="<?php echo e(route('usuarios.pdf')); ?>">Aqui</a> Para descargar en pdf </p>


<div class="container">
	<div class="row">
		<div class="col-lg-12">
			<div class="table-responsive">
				
				
			<table id="example" class="display nowrap" style="width:100%">

        <thead>
            <tr>
                <th>Nombre</th>
                <th>Apellido paterno</th>
                <th>Apellido materno</th>
                <th>Email</th>
                <th>Tipo Usuario</th>
				<th>Telefono</th>
				<th>Fecha de nacimiento</th>

            </tr>
        </thead>
        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
            <tr>				
				<td><?php echo e($usuario->nombre); ?></td>
				<td><?php echo e($usuario->app); ?></td>
				<td><?php echo e($usuario->apm); ?></td>							
				<td><?php echo e($usuario->email); ?></td>
				<td><?php echo e($usuario->tipo_usuario); ?></td>							
				<td><?php echo e($usuario->tel); ?></td>	
				<td><?php echo e($usuario->fn); ?></td>							

			</tr>
        
		</tbody>
       
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

			</div>

		</div>
		

	</div>

</div>
<a href="<?php echo e(route('home')); ?>" class="button big">Regresar</a><br><br>




	</body>
</html>

<!-- editar  --><?php /**PATH C:\Users\cf911\Desktop\Urban\resources\views/reportes/reporte_usuarios.blade.php ENDPATH**/ ?>