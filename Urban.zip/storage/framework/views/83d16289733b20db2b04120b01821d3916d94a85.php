<!DOCTYPE HTML>

<html>

<head>
	<title>Inicio</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>" />
	<script src=" <?php echo e(asset('js/jquery-3.3.1.js')); ?> "></script>
    	<script src=" <?php echo e(asset('js/jquery-ui.js')); ?> "></script>

</head>

<body class="is-preload">

	<!-- Wrapper -->
	<div id="wrapper">

		<!-- Main -->
		<div id="main">
			<div class="inner">

			<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


				<h2>Citas realizadas</h2>
			
				<form action="<?php echo e(route ('informacion')); ?>" method="GET" name="nuevo" enctype="multipart/form-data">

				<div>
					Selecciona el empleado <select name="id_empleado" id="id_empleado" >
						<option value="">--Selecciona el empleado--</option>
					<?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($empleado->id_empleado); ?>"><?php echo e($empleado->nombre); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					
					<input type="submit" value="Enviar">
					
					
				
				
					
				</div>
				</form>

			</div>
		</div>

		<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	</div>

	<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	
</body>

</html><?php /**PATH C:\xampp\htdocs\Urban\resources\views/templates/citasEmpleado.blade.php ENDPATH**/ ?>