<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Reporte de Servicios</h1>
    <table>
        <thead>
            <tr>
                <th>Nombre servicio</th>
                <th>Descripcion</th>
                <th>Precio</th>
            </tr>
        </thead>
        <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
            <tr>				
				<td><?php echo e($servicio->nombre_servicio); ?></td>
				<td><?php echo e($servicio->descripcion); ?></td>
				<td><?php echo e($servicio->precio); ?></td>							
			</tr>
        
		</tbody>
       
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html><?php /**PATH C:\Users\cf911\Desktop\Urban\resources\views/pdf/servicios.blade.php ENDPATH**/ ?>