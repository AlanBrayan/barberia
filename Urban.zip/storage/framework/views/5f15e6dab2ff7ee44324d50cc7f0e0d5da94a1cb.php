<!DOCTYPE HTML>
<!--
	Editorial by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>

<head>
	<title>Inicio</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>" />

	<script src=" <?php echo e(asset('js/jquery-3.3.1.js')); ?> "></script>
	<script src=" <?php echo e(asset('js/jquery-ui.js')); ?> "></script>
</head>

<body class="is-preload">

	<!-- Wrapper -->
	<div id="wrapper">

		<!-- Main -->
		<div id="main">
			<div class="inner">

			<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form action="<?php echo e(route ('guardarEmpleados')); ?>" method="POST" name="nuevo" enctype="multipart/form-data">

        <?php echo e(csrf_field()); ?>

  
        <div>
            <td>Nombre: </td>
            <td><input type="text" id="nombre" class="nombre" name="nombre"></td>

        </div>
        <?php if($errors->first('nombre')): ?> <i><?php echo e($errors -> first ('nombre')); ?></i><?php endif; ?>

        <div>
            <td>Ap. Paterno: </td>
            <td><input type="text" id="app" class="app" name="app"></td>

        </div>
        <?php if($errors->first('app')): ?> <i><?php echo e($errors -> first ('app')); ?></i><?php endif; ?>

        <div>
            <td>Ap. Materno: </td>
            <td><input type="text" id="apm" class="apm" name="apm"></td><br>

        </div>
        <?php if($errors->first('apm')): ?> <i><?php echo e($errors -> first ('apm')); ?></i><?php endif; ?>

        <div>
            <td>Fecha de nacimiento :</td>  
            <td><input type="date" name="fn" id="fn"></td><br>
            <td><span id="sfecha" class="sfecha"></span></td><br>

        </div>
        <?php if($errors->first('fn')): ?> <i><?php echo e($errors -> first ('fn')); ?></i><?php endif; ?>

        
        <div>
            Telefono : <input type="text" name="tel" value="<?php echo e(old('tel')); ?>" id="tel"><br>
            <?php if($errors->first('tel')): ?> <i><?php echo e($errors -> first ('tel')); ?></i><?php endif; ?>
        </div>
        
            <div>
            <td>Especialidad : </td>
            <td><input type="text" id="especialidad" class="especialidad" name="especialidad"></td><br>

            </div>
            <?php if($errors->first('especialidad')): ?> <i><?php echo e($errors -> first ('especialidad')); ?></i><?php endif; ?>

            <br>
		    Selecciona una imagen  : <input type="file" name="img"><br><br><br>

            <input type="submit" value="Enviar">
            </form>

			</div>
		</div>
		<script>
		$(document).ready(function(){
			$("#nombre").keyup(function(){
							var txtapm = $("#nombre").val();
                            var formato = /^[A-Za-z\_\-\.\s\xF1\xD1]+$/;
							
                            if(formato.test(txtapm)){ $("#nombre").css({"border": "1px solid #0F0"}).fadeIn(2000); }
                            else{ $("#nombre").css({"border": "1px solid #F00"}).fadeIn(2000); }
                        });
					
			//--------------------------------------------------------------------
			const $precio = document.querySelector("#precio");
                            $precio.addEventListener("keydown", event => {
                            console.log(event.key);
                            if(patron.test(event.key)){
                                $('#precio').css({ "border":"1px solid #0C0" });
                            }  
                            else{
                                if(event.keyCode==8){ console.log("backspace"); }
                                else{ event.preventDefault(); }
                            }  
                            });
			// -------------------------------------------------------------------
			$("#descripcion").keyup(function(){
							var txtapm = $("#descripcion").val();
                            var formato = /^[A-Za-z0-9\_\-\.\s\xF1\xD1]+$/;
						
                            if(formato.test(txtapm)){ $("#descripcion").css({"border": "1px solid #0F0"}).fadeIn(2000); }
                            else{ $("#descripcion").css({"border": "1px solid #F00"}).fadeIn(2000); }
                        });
			
			// ------------------------------------------------------------------------------
			
					});
		
		</script>
		
		<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	</div>

	<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\xampp\htdocs\Urban\resources\views/templates/registrar_empleados.blade.php ENDPATH**/ ?>