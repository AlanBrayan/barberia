<!DOCTYPE HTML>
<!--
	Editorial by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>

<head>
	<title>Inicio</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>" />

</head>

<body class="is-preload">

	<!-- Wrapper -->
	<div id="wrapper">

		<!-- Main -->
		<div id="main">
			<div class="inner">

			<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


				<h2>Citas realizadas</h2>
				<div>
					<form action="<?php echo e(route ('informacion')); ?>" method="GET" name="nuevo" enctype="multipart/form-data">

					
						Selecciona el empleado <select name="id_empleado" id="id_empleado" >
							<option value="">--Selecciona el empleado--</option>
						<?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($empleado->id_empleado); ?>"><?php echo e($empleado->nombre); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>

						<input type="submit" value="Enviar">
					</form>
                    <table>
                        <thead>
                            <tr>
                                <th><h3>Empleado</h3></th>
								<th><h3>Usuario del servicio</h3></th>
								<th><h3>Fecha</h3></th>
								<th><h3>Hora</h3></th>
								<th><h3>Servicio</h3></th>
                            </tr>
                        </thead>
                        <?php $__currentLoopData = $usus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(session('session_tipo') == 1): ?>
                        <tbody>
                        
                      
                            <tr>
                            
                                <td><?php echo e($usu->id_empleado); ?></td>

                               
                                <td><?php echo e($usu->id_usuario); ?></td>
                              

                                <td><?php echo e($usu->fecha); ?></td>
                                <td><?php echo e($usu->hora); ?></td>
                                <td><?php echo e($usu->id_servicio); ?></td>
                                
                            </tr>
                        
                        
                        </tbody>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>

                    
                        
                    
				</div>


				<div>
					
					
				</div>

			</div>
		</div>

		<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	</div>

	<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\Users\cf911\Desktop\Urban\resources\views/templates/informacion.blade.php ENDPATH**/ ?>