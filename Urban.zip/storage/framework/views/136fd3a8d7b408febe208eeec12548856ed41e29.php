<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Reporte de Usuarios</h1>
    <table>
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Apellido paterno</th>
                <th>Apellido materno</th>
                <th>Email</th>
                <th>Tipo Usuario</th>
				<th>Telefono</th>
				<th>Fecha de nacimiento</th>

            </tr>
        </thead>
        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
            <tr>				
				<td><?php echo e($usuario->nombre); ?></td>
				<td><?php echo e($usuario->app); ?></td>
				<td><?php echo e($usuario->apm); ?></td>							
				<td><?php echo e($usuario->email); ?></td>
				<td><?php echo e($usuario->tipo_usuario); ?></td>							
				<td><?php echo e($usuario->tel); ?></td>	
				<td><?php echo e($usuario->fn); ?></td>							

			</tr>
        
		</tbody>
       
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html><?php /**PATH C:\Users\cf911\Desktop\Urban\resources\views/pdf/usuarios.blade.php ENDPATH**/ ?>