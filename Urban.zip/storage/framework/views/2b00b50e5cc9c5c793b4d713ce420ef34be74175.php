<!DOCTYPE HTML>
<!--
	Editorial by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>

<head>
	<title>Inicio</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>" />

</head>

<body class="is-preload">

	<!-- Wrapper -->
	<div id="wrapper">

		<!-- Main -->
		<div id="main">
			<div class="inner">

			<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			<h2>Nuevo Material</h2>


				<form action="<?php echo e(route ('guardarMateriales')); ?>" method="POST" name="nuevo">

					<?php echo e(csrf_field()); ?>


					<div style="padding: 1%;">
						Nombre del material : <input type="text"  id="nombre" name="nombre" value="<?php echo e(old('nombre')); ?>">
                        
					</div>
					<?php if($errors->first('nombre')): ?> <i><?php echo e($errors -> first ('nombre')); ?></i><?php endif; ?>

					<div style="padding: 1%;">
						Tipo de material : <input type="text"  id="tipo_material" name="tipo_material" value="<?php echo e(old('tipo_material')); ?>">
					</div>
					<?php if($errors->first('tipo_material')): ?> <i><?php echo e($errors -> first ('tipo_material')); ?></i><?php endif; ?>
					
					<hr>

					<input type="submit" value="Enviar">
				</form>

			</div>
		</div>

		<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	</div>

	<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	
	<script type="text/javascript">

	$("#nombre").keyup(function(){
							var txtapm = $("#nombre").val();
                            var formato = /^[A-Za-z\_\-\.\s\xF1\xD1]+$/;
							
				

                            if(formato.test(txtapm)){ $("#nombre").css({"border": "1px solid #0F0"}).fadeIn(2000); }
                            else{ $("#nombre").css({"border": "1px solid #F00"}).fadeIn(2000); }
                        });
//----------------------Editar tipo material----------------------------------------
const $input = document.querySelector("#tipo_material");
                            const patron = /[A-Za-z]+/;

                            $input.addEventListener("keydown", event => {
                            console.log(event.key);
                            if(patron.test(event.key)){
                                $('#tipo_material').css({ "border": "1px solid #0F0" });
                            }  
                            else{
                                if(event.keyCode==8){ console.log("backspace"); }
                                else{ event.preventDefault(); }
                            }  
                            });
	</script>

</body>

</html><?php /**PATH C:\xampp\htdocs\proyecto_integrador2\resources\views/templates/registrar_materiales.blade.php ENDPATH**/ ?>