<!DOCTYPE HTML>
<!--
	Editorial by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>

<head>
	<title>Inicio</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>" />

</head>

<body class="is-preload">

	<!-- Wrapper -->
	<div id="wrapper">

		<!-- Main -->
		<div id="main">
			<div class="inner">

			<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			<h2>Editar Productos</h2>


				<form action="<?php echo e(route('salvarEmpleados', ['id' => $usu->id_empleado])); ?>" method="POST" name="nuevo3" enctype="multipart/form-data">

					<?php echo e(csrf_field()); ?>

					<?php echo e(method_field('PUT')); ?> 

					<div style="padding: 1%;">
						Nombre: <input type="text" name="nombre" value="<?php echo e($usu->nombre); ?>">
					</div>
					<?php if($errors->first('nombre')): ?> <i><?php echo e($errors -> first ('nombre')); ?></i><?php endif; ?>

					<div style="padding: 1%;">
						Apellido paterno: <input type="text" name="app" value="<?php echo e($usu->app); ?>">
					</div>
					<?php if($errors->first('app')): ?> <i><?php echo e($errors -> first ('app')); ?></i><?php endif; ?>
					
					<div style="padding: 1%;">
						Apellido materno : <input type="text" name="apm" value="<?php echo e($usu->apm); ?>">
					</div>
					<?php if($errors->first('apm')): ?> <i><?php echo e($errors -> first ('apm')); ?></i><?php endif; ?>

					<div style="padding: 1%;">
						Telefono: <input type="text" name="tel" value="<?php echo e($usu->tel); ?>">
					</div>
					<?php if($errors->first('tel')): ?> <i><?php echo e($errors -> first ('tel')); ?></i><?php endif; ?>


					<div style="padding: 1%;">
						Fecha de nacimiento : <input type="date" name="fn" value="<?php echo e($usu->fn); ?>">
					</div>
					<?php if($errors->first('fn')): ?> <i><?php echo e($errors -> first ('fn')); ?></i><?php endif; ?>

					<div style="padding: 1%;">
						Especialidad : <input type="text" name="especialidad" value="<?php echo e($usu->especialidad); ?>">
					</div>
					<?php if($errors->first('especialidad')): ?> <i><?php echo e($errors -> first ('especialidad')); ?></i><?php endif; ?>
					
					
					<hr>

					<input type="submit" value="Enviar">
				</form>

			</div>
		</div>

		<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	</div>

	<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\Users\cf911\Desktop\Urban\resources\views/templates/editarEmpleados.blade.php ENDPATH**/ ?>