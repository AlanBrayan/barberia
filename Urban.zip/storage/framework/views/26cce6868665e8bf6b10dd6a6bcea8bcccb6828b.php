<!DOCTYPE html>
<html>
    <head>
        <title>Email Urbancut</title>
    </head>
<body>
    <h1>USUARIO CREADO</h1>
    <p>Has creado usuario en nuestra plataforma URBANCUT</p>
    <p></p>
    <p>Gracias</p>
    <img src="https://utvt.edomex.gob.mx/sites/utvt.edomex.gob.mx/files/images/1%20copia.jpg">
</body>
</html><?php /**PATH C:\Users\Alanb\OneDrive\Escritorio\Urban\resources\views/emails/correoGuardado.blade.php ENDPATH**/ ?>