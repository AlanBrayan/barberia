<!DOCTYPE HTML>
<!--
	Editorial by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>

<head>
	<title>Inicio</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>" />
	<script src=" <?php echo e(asset('js/jquery-3.3.1.js')); ?> "></script>
    	<script src=" <?php echo e(asset('js/jquery-ui.js')); ?> "></script>

</head>

<body class="is-preload">

	<!-- Wrapper -->
	<div id="wrapper">

		<!-- Main -->
		<div id="main">
			<div class="inner">

			<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



				
					<?php echo e(csrf_field()); ?>

					
					<div style="padding: 1%;">

						Selecciona el usuario <select name="id_usuario" id="id_usuario" required autocomplete="off">
							<option value="">--Selecciona un usuario--</option>
							<?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($usuario->id_usuario); ?>"><?php echo e($usuario->nombre); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
						
					</div>

					<div style="padding: 1%;">
						Escribe tu direccion: <input type="text" name="direccion" value="<?php echo e(old('direccion')); ?>" id="direccion" required autocomplete="off">
					</div>
					<?php if($errors->first('direccion')): ?> <i><?php echo e($errors -> first ('direccion')); ?></i><?php endif; ?>
					

					<div style="padding: 1%;">
						Selecciona el producto a comprar 
						<select name="id_producto" id="id_producto">
							<option value="">--Selecciona un producto--</option>
							<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($producto->id_producto); ?>-<?php echo e($producto->precio); ?>">
								<?php echo e($producto->nombre_producto); ?> 
							</option><br>
							
							
				

						
							
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						</select>

						
					</div>
					<hr>
					
					<div style="padding: 1%;">
						Cantidad: <input type="number" name="cantidad" value="<?php echo e(old('cantidad')); ?>" id="cantidad" required autocomplete="off"><br>
					</div>
					<?php if($errors->first('cantidad')): ?> <i><?php echo e($errors -> first ('cantidad')); ?></i><?php endif; ?>
					<hr>

					
					
					
					<div id="montoTotal"> 
						
					</div>


					

					<input type="submit" value="Enviar" id="submit">
					

			</div>
		</div>

		<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	</div>

	<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
<script type="text/javascript">
    
	$(document).ready(function() {
        

		$('#cantidad').change(function() {
            const producto = $('#id_producto').val();
			const separacion = producto.split('-');
			const precio = separacion[1];
			const id = separacion[0];
            //console.log("Producto seleccionada:" + producto);
			//console.log("Precio:" + precio); 
			//console.log("ID:" + id); 

			var cantidad = $('#cantidad').val();
			//console.log(cantidad);

			var montoTotal=precio*cantidad;
			//console.log(montoTotal);

			if(cantidad = 0){
				$('#montoTotal').empty();
			}else{
				 
				$('#montoTotal').html("MONTO TOTAL = " + montoTotal);
				$('#montoTotal').html("MONTO TOTAL = " + montoTotal);

			}
        })

		

		$('#submit').click(function() {
                var url = "guardarVentas/";
            
				var producto = $('#id_producto').val();
				var separacion = producto.split('-');
				var precio1 = separacion[1];
				var id = separacion[0];


                var id_usuario = $("#id_usuario").val();
                var direccion = $("#direccion").val();
                var id_producto = id;
                var cantidad = $("#cantidad").val();
				var precio = precio1;		
				var monto_total= "$ " + (precio*cantidad);
				console.log(id_usuario);
				console.log(direccion);
				console.log(id_producto);
				console.log(cantidad);
				console.log(precio);
				console.log(monto_total);
				
                var formData = new FormData();
                formData.append('_token', $('input[name=_token]').val());
                formData.append('id_usuario',id_usuario);
                formData.append('direccion',direccion);
                formData.append('id_producto',id_producto);
                formData.append('cantidad',cantidad);
                formData.append('precio',precio);
                formData.append('monto_total',monto_total);
            
                $.ajax({
                    type:"POST",
                    url: url,
                    data: formData,
                    processData: false, // tell jQuery not to process the data
                    contentType: false, // tell jQuery not to set contentType
                    success: function(data) {
                        setTimeout(function() {
                            location.reload(true);
                        }, 100);
                    },
                    error:function(e) {
                        console.log(e);
                    }
                
                });

                



});
		
    });
</script>

</html><?php /**PATH C:\Users\cf911\Desktop\Urban\resources\views/templates/registrar_ventas.blade.php ENDPATH**/ ?>