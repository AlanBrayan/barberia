<!DOCTYPE HTML>
<!--
	Editorial by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>

<head>
	<title>Inicio</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>" />

</head>

<body class="is-preload">

	<!-- Wrapper -->
	<div id="wrapper">

		<!-- Main -->
		<div id="main">
			<div class="inner">

			<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			<h2>Editar Productos</h2>


				<form action="<?php echo e(route('salvarServicios', ['id' => $usu->id_servicio])); ?>" method="POST" name="nuevo3" enctype="multipart/form-data">

					<?php echo e(csrf_field()); ?>

					<?php echo e(method_field('PUT')); ?> 

					<div style="padding: 1%;">
						Nombre Del Servicio : <input type="text" name="nombre_servicio" value="<?php echo e($usu->nombre_servicio); ?>">
					</div>
					<?php if($errors->first('nombre_servicio')): ?> <i><?php echo e($errors -> first ('nombre_servicio')); ?></i><?php endif; ?>


					<div style="padding: 1%;">
					<!-- como cambiar el tamaño -->
						Descripcion : <input type="text" name="descripcion" value="<?php echo e($usu->descripcion); ?>">
					</div>
					<?php if($errors->first('descripcion')): ?> <i><?php echo e($errors -> first ('descripcion')); ?></i><?php endif; ?>

					<div style="padding: 1%;">
						Precio : <input type="text" name="precio" value="<?php echo e($usu->precio); ?>">
					</div>
					<?php if($errors->first('precio')): ?> <i><?php echo e($errors -> first ('precio')); ?></i><?php endif; ?>
					
					
					<hr>

					<input type="submit" value="Enviar">
				</form>

			</div>
		</div>

		<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	</div>

	<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\xampp\htdocs\Urban\resources\views/templates/editarServicios.blade.php ENDPATH**/ ?>