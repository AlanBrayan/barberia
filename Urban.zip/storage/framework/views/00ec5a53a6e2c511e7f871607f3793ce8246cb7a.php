<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Reporte de productos</h1>
    <table>
        <thead>
            <tr>
                <th>Nombre producto</th>
                <th>No existencias</th>
                <th>Precio</th>
                <th>Descripcion</th>
            </tr>
        </thead>
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
            <tr>				
				<td><?php echo e($producto->nombre_producto); ?></td>
				<td><?php echo e($producto->no_existencias); ?></td>
				<td><?php echo e($producto->precio); ?></td>							
				<td><?php echo e($producto->descripcion); ?></td>							
			</tr>
        
		</tbody>
       
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html><?php /**PATH C:\Users\cf911\Desktop\Urban\resources\views/pdf/productos.blade.php ENDPATH**/ ?>