<!DOCTYPE HTML>
<!--
	Editorial by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>

<head>
	<title>Inicio</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>" />

</head>

<body class="is-preload">

	<!-- Wrapper -->
	<div id="wrapper">

		<!-- Main -->
		<div id="main">
			<div class="inner">

			<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


				<h2>Citas realizadas</h2>
				<?php if(session('session_tipo') == 1): ?>
				<div>
					<form action="<?php echo e(route ('informacion')); ?>" method="GET" name="nuevo" enctype="multipart/form-data">

					
						Selecciona el empleado <select name="id_empleado" id="id_empleado" >
							<option value="">--Selecciona el empleado--</option>
						<?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($empleado->id_empleado); ?>"><?php echo e($empleado->nombre); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>

						<input type="submit" value="Enviar">





				
					</form>
				</div>
				 <?php endif; ?>


				<div>
					
					<table>
						<thead>
							<tr>

								<th><h3>Usuario</h3></th>
								<th><h3>Empleado</h3></th>
								<th><h3>Fecha</h3></th>
								<th><h3>Hora</h3></th>
								<th><h3>Servicio</h3></th>
								
								<th><h3>Eliminar Registro</h3></th>
							</tr>
						</thead>
						<?php $__currentLoopData = $usus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if(session('session_tipo') == 1): ?>
						<tbody>
							<tr>



							<?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($usu->id_usuario == $usuario->id_usuario): ?>



								<td><?php echo e($usuario->nombre); ?></td>
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							<?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($usu->id_empleado == $empleado->id_empleado): ?>



								<td><?php echo e($empleado->nombre); ?></td>
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


								
								<td><?php echo e($usu->fecha); ?></td>
								<td><?php echo e($usu->hora); ?></td>



								
								<?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($usu->id_servicio == $servicio->id_servicio): ?>



								<td><?php echo e($servicio->nombre_servicio); ?></td>
								<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								
								
								<td><h3><a href="<?php echo e(route('borrarCita', ['id' => $usu->id_cita])); ?>"><i class="fas fa-trash-alt"></i> Eliminar</a></h3></td>
							

							</tr>
						</tbody>
						<?php endif; ?>


						<?php if(session('session_tipo') == 2): ?>
						<?php if(session('session_id') == $usu->id_usuario): ?>)
						<tbody>
							<tr>



							<?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($usu->id_usuario == $usuario->id_usuario): ?>



								<td><?php echo e($usuario->nombre); ?></td>
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							<?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($usu->id_empleado == $empleado->id_empleado): ?>



								<td><?php echo e($empleado->nombre); ?></td>
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


								
								<td><?php echo e($usu->fecha); ?></td>
								<td><?php echo e($usu->hora); ?></td>



								
								<?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($usu->id_servicio == $servicio->id_servicio): ?>



								<td><?php echo e($servicio->nombre_servicio); ?></td>
								<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								
								
								<td><h3><a href="<?php echo e(route('borrarCita', ['id' => $usu->id_cita])); ?>"><i class="fas fa-trash-alt"></i> Eliminar</a></h3></td>
							

							</tr>
						</tbody>
						<?php endif; ?>
						<?php endif; ?>
						
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
					</table>
				</div>

			</div>
		</div>

		<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	</div>

	<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\xampp\htdocs\Urban\resources\views/templates/citas.blade.php ENDPATH**/ ?>