<!DOCTYPE HTML>
<!--
	Editorial by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>

<head>
	<title>Inicio</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>" />

</head>

<style>
	.card {
		box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
		transition: 0.3s;

		border-radius: 5px;
		text-align: center;
	}

	.card:hover {
		box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
	}

	img {
		border-radius: 5px 5px 0 0;
	}

	.container {
		padding: 2px 16px;
	}
</style>

<body class="is-preload">

	<!-- Wrapper -->
	<div id="wrapper">

		<!-- Main -->
		<div id="main">
			<div class="inner">

				<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


				<h2>Perfil</h2>
				<form action="<?php echo e(route('eliminar_usuario')); ?>" method="GET">
				<div>
				<?php $__currentLoopData = $usus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($usu->id_usuario == session('session_id')): ?>

					<div class="card">
						<!-- <img src="<?php echo e(asset('img/'.$usu->img)); ?>" alt="Imagen" width="200" height="200"> -->
						<div class="container">
						<table>
							<td><br>
								<th><h3>Nombre : <?php echo e($usu->nombre); ?> <?php echo e($usu->app); ?> <?php echo e($usu->apm); ?> <br>
								
							
								</th><br>
							</td>
							<td>
								Email: <?php echo e($usu->email); ?> <br>
								 <input type="hidden" name="email" value="<?php echo e($usu->email); ?>">

								<?php if($usu->tipo_usuario == 1): ?>
								<center>
									ADMINISTRADOR
								</center>
								<?php endif; ?>
								Fecha de nacimiento: <?php echo e($usu->fn); ?> <br>
								Telefono: <?php echo e($usu->tel); ?> <br>
								<br></br>
						<input type="submit" value="Eliminar usuario">								

							</td>
						</table>

						</div>
					</div>
					<?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


				</div>
				</form>
			</div>
		</div>

		<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	</div>

	<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\xampp\htdocs\Urban\resources\views/templates/detalle_usuario.blade.php ENDPATH**/ ?>