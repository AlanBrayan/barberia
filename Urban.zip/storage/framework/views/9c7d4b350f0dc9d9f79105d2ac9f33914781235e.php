<!DOCTYPE HTML>
<!--
	Editorial by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>

<head>
	<title>Inicio</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>" />

	<script src=" <?php echo e(asset('js/jquery-3.3.1.js')); ?> "></script>
	<script src=" <?php echo e(asset('js/jquery-ui.js')); ?> "></script>
</head>

<body class="is-preload">

	<!-- Wrapper -->
	<div id="wrapper">

		<!-- Main -->
		<div id="main">
			<div class="inner">

			<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


				<form action="<?php echo e(route ('guardarServicios')); ?>" method="POST" name="nuevo" enctype="multipart/form-data">

					<?php echo e(csrf_field()); ?>


					<div style="padding: 1%;">
						<td>Nombre Del servicio :</td>
						<td><input type="text" name="nombre_servicio" id="nombre_servicio" value="<?php echo e(old('nombre_servicio')); ?>"></td>
					</div>
					<?php if($errors->first('nombre_servicio')): ?> <i><?php echo e($errors -> first ('nombre_servicio')); ?></i><?php endif; ?>

					<div style="padding: 1%;">
					<!-- como cambiar el tamaño -->
						Descripcion : <input type="text" name="descripcion" id="descripcion" value="<?php echo e(old('descripcion')); ?>">
					</div>
					<?php if($errors->first('descripcion')): ?> <i><?php echo e($errors -> first ('descripcion')); ?></i><?php endif; ?>

                    <div style="padding: 1%;">
						Precio : <input type="number" name="precio" id="precio">
					</div>
					<?php if($errors->first('precio')): ?> <i><?php echo e($errors -> first ('precio')); ?></i><?php endif; ?>
	
					<br>
					Selecciona una imagen respecto al servicio ingresado : <input type="file" name="img"><br><br><br>

					<hr>

					<input type="submit" value="Enviar">
				</form>

			</div>
		</div>
		<script>
		$(document).ready(function(){
			$("#nombre_servicio").keyup(function(){
							var txtapm = $("#nombre_servicio").val();
                            var formato = /^[A-Za-z\_\-\.\s\xF1\xD1]+$/;
							
                            if(formato.test(txtapm)){ $("#nombre_servicio").css({"border": "1px solid #0F0"}).fadeIn(2000); }
                            else{ $("#nombre_servicio").css({"border": "1px solid #F00"}).fadeIn(2000); }
                        });
					
			//--------------------------------------------------------------------
			const $precio = document.querySelector("#precio");
                            $precio.addEventListener("keydown", event => {
                            console.log(event.key);
                            if(patron.test(event.key)){
                                $('#precio').css({ "border":"1px solid #0C0" });
                            }  
                            else{
                                if(event.keyCode==8){ console.log("backspace"); }
                                else{ event.preventDefault(); }
                            }  
                            });
			// -------------------------------------------------------------------
			$("#descripcion").keyup(function(){
							var txtapm = $("#descripcion").val();
                            var formato = /^[A-Za-z0-9\_\-\.\s\xF1\xD1]+$/;
						
                            if(formato.test(txtapm)){ $("#descripcion").css({"border": "1px solid #0F0"}).fadeIn(2000); }
                            else{ $("#descripcion").css({"border": "1px solid #F00"}).fadeIn(2000); }
                        });
			
			// ------------------------------------------------------------------------------
			
					});
		
		</script>
		
		<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	</div>

	<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\xampp\htdocs\Urban\resources\views/templates/registrar_servicios.blade.php ENDPATH**/ ?>