<!DOCTYPE html>
<html>

    <table border="0">
        <tr>
            <th>Nombre:</th>
            <td>
                <input type="text" name="nombre">
            </td>
        </tr>
        <tr>
          
            <td>
                <input type="hidden" name="email" value="al221911806@gmail.com">
            </td>
        </tr>
        <tr>
            <th>Ingresa tu email para contactarnos: </th>
            <td>
                <input type="text" name="correo">
            </td>
        </tr>
        <tr>
            <th>Asunto:</th>
            <td>
                <input type="text" name="asunto">
            </td>
        </tr>
        <tr>
            <th>Contenido:</th>
            <td>
                <textarea name="contenido"></textarea>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <input type="submit" value="Enviar">
            </td>
        </tr>
    </table>
    </form>

  </div>
 </body>
</html>



<?php /**PATH C:\xampp\htdocs\Urban\resources\views/emailform.blade.php ENDPATH**/ ?>