<?php

use Illuminate\Http\Request;

Route::resource('productos', ProductosController::class);
Route::resource('servicios', ServiciosController::class);



