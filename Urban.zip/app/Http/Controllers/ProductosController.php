<?php

namespace App\Http\Controllers;

use App\ProductosModel;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ProductosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return ProductosModel::all();

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */


    /**
     * Display the specified resource.
     *
     * @param  \App\ProductosModel  $productosModel
     * @return \Illuminate\Http\Response


     */

    public function store(Request $request)
    {
        $producto = ProductosModel::create($request->all());
        return response()->json(['Mensaje'=>'Producto creado correctamente', 200]);
    }


    public function show($id_producto)
    {
        $producto = ProductosModel::find($id_producto);
        if(is_null($producto))
        {
            return response()->json([''=>'Producto no encontrado']);
        }
        return response()->json($producto::find($id_producto), 200);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ProductosModel  $productosModel
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProductosModel $productosModel)
    {
        $request->validate([
            'nombre_producto' => 'required',
            'no_existencias' => 'required',
            'precio' => 'required',
            'descripcion' => 'required',
        ]);

        $productosModel = update($request->all());
        return response()->json($productosModel, 200);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ProductosModel  $productosModel
     * @return \Illuminate\Http\Response
     */
    public function destroy($id_producto)
    {
        $producto = ProductosModel::findOrFail($id_producto);
        $producto->delete();
    }
}
